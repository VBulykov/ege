count = 0
for x in range(1,15):
  for y in range(-6,7):
    if y > -x/2 and y < x/2 and y :
       count += 1
  print( x, count )
print( count )

