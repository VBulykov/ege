from itertools import permutations

print( len(set(permutations('БИТКОИН'))) )