x = 1
for n in range(2073, 2070, -1):
  x *= 3*n + 5

print( x )