def F( n ):
  return n if n < 10 else F(G(n))
def G( n ):
  return F(n) if n < 10 else G(n//10) + G(n%10)

count = 0
for n in range(100000, 200000):
  if F(n) == 3:
    count += 1

print( count )

print( 11111111 )
