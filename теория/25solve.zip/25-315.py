from fnmatch import fnmatch

for n in range(0, 10**8, 2025):
  if fnmatch( str(n), '12*34?5' ):
    print( n, n//2025 )


