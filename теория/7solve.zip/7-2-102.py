
# 1 sec

v1sec = 32000 * 16 * 4
t = 50*1024*1024*8 / 0.2 / v1sec
print( t / 60 )
